Assignment URL

https://docs.google.com/document/d/18US5bpwqasINqA68-xojGItFKd97ZbT9KE7hh1awSRw/edit?usp=sharing