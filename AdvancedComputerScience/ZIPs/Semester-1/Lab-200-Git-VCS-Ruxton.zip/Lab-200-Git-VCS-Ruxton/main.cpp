#include <iostream>
#include <sstream>
using namespace std;

int main() {
  std::cout << "Hello World!\n";
}