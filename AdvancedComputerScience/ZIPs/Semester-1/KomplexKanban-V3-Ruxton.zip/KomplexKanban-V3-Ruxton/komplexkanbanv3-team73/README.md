# README

# Complex Library

The complex library aims to implement standard math functions such as sin, cos, and exp to account for imaginary components passed to them.

## Getting Started

Download the github files as a zip and extract to a folder in your files to get the library. Then, you can use your compiler to turn the library into an executable where you can run the program and access any methods from the library.

### Prerequisites

C++11, a compiler (such as g++) that can compile C++11, Catch2, and Make in order to run the make file.

### Installing

1. Download the github repository as a zip
2. Extract the file to a folder in your file explorer
3. Write the following line in your main c++ file to include the library

```cpp
#include "complex.hpp"
```

4. Open command line and run the following command

```bash
make test
```

5. If you see the line

```
All tests passed (110 assertions in 22 test cases)
```

then that means it's working!

6. Now write a line in your main program, such as

```cpp
arcsin(complex(0, 0))
```

and see if it runs. If you're output looks something like:

```
0.000000 + 0.000000i
```

then that means your implementation is working.

## Running the tests

If you ever want to modify the tests you can go into the main_test and add the following into the code:

```cpp
REQUIRE(/*<function>*/(complex(/*<re>*/, /*<im>*/)) == complex(/*<re>*/, /*<im>*/));
```
(where <function> is the function name, re is the real component, and im is the imaginary component for the input and output values of the test, respectively)

in the test case for the corresponding function and re-run them using the following command in your shell:

```bash
make test
```

OR if you want to re-compile them with the following:

```bash
make clean
```

### Break down of the tests

The given tests are standardized edge cases for the functions, to test the limits of the functions to ensure that they all work as intended.

For example, the function sin(x) might have tests that look like that following:
```cpp
TEST_CASE("sin", "[sin]") {
  REQUIRE(sin(complex(0, 0)) == (complex(0, 0)));
  REQUIRE(sin(complex((PI / 2), 0)) == (complex(1, 0)));
  REQUIRE(sin(complex(PI, 0)) == (complex(0, 0)));
  REQUIRE(sin(complex(-(PI / 2), 0)) == (complex(-1, 0)));
}
```
which is intended to test as many of the values that can cause problems with the functions.

### Coding Style Tests

Generally, the purpose for these kinds of tests is to check if the implementation of the library in your code works correctly, and the reason we handpick edge-cases to test is so that we already know that it works for some of the simpler values, but we maximize the possibility for error when running the tests, to truly test the versatility of each method.

In the case of tan, we would want to run the test
```cpp
TEST_CASE("tan", "[tan]") {
  REQUIRE(tan(complex((PI/2), 0)) == NULL);
}
```
in order to make sure our implementations for the methods are handling cases where C++ might break as a result of trying to access an undefined value, NULL, or some other special case with respect to each function.

## Built With

* [GNU Tools](https://www.gnu.org/software/gcc/) - GNU compiler tools
* [Repl.it Tools](https://docs.replit.com/category/workspace-features) - Repl.it IDE tools


## Structure
``` text
.
├── komplexkanbanv3-team73
│   ├── main
│   ├── main-debug
│   ├── Makefile
│   ├── README.md
│   ├── replit.nix
│   ├── result -> /nix/store/ycbh5a0p3ksbynxirbs5j1rzajb901pj-nix-shell
│   ├── src
│   │   ├── Cmakelists.txt
│   │   ├── CMakeLists.txt
│   │   ├── complex_abs.hpp
│   │   ├── complex_abs.o
│   │   ├── complex_acos.hpp
│   │   ├── complex_acos.o
│   │   ├── complex_arg.hpp
│   │   ├── complex_arg.o
│   │   ├── complex_asin.hpp
│   │   ├── complex_asin.o
│   │   ├── complex_atan.hpp
│   │   ├── complex_atan.o
│   │   ├── complex_conj.hpp
│   │   ├── complex_conj.o
│   │   ├── complex_cosh.hpp
│   │   ├── complex_cosh.o
│   │   ├── complex_cos.hpp
│   │   ├── complex_cos.o
│   │   ├── complex_exp.hpp
│   │   ├── complex_exp.o
│   │   ├── complex.hpp
│   │   ├── complex_imag.hpp
│   │   ├── complex_imag.o
│   │   ├── complex_log10.hpp
│   │   ├── complex_log10.o
│   │   ├── complex_log.hpp
│   │   ├── complex_log.o
│   │   ├── complex_norm.hpp
│   │   ├── complex_norm.o
│   │   ├── complex.o
│   │   ├── complex_operator_divide_equals.hpp
│   │   ├── complex_operator_divide_equals.o
│   │   ├── complex_operator_divide.hpp
│   │   ├── complex_operator_divide.o
│   │   ├── complex_operator_equals.hpp
│   │   ├── complex_operator_equals.o
│   │   ├── complex_operator_input.hpp
│   │   ├── complex_operator_input.o
│   │   ├── complex_operator_minus_equals.hpp
│   │   ├── complex_operator_minus_equals.o
│   │   ├── complex_operator_minus.hpp
│   │   ├── complex_operator_minus.o
│   │   ├── complex_operator_multiply_equals.hpp
│   │   ├── complex_operator_multiply_equals.o
│   │   ├── complex_operator_multiply.hpp
│   │   ├── complex_operator_multiply.o
│   │   ├── complex_operator_output.hpp
│   │   ├── complex_operator_output.o
│   │   ├── complex_operator_plus_equals.hpp
│   │   ├── complex_operator_plus_equals.o
│   │   ├── complex_operator_plus.hpp
│   │   ├── complex_operator_plus.o
│   │   ├── complex_polar.hpp
│   │   ├── complex_polar.o
│   │   ├── complex_pow.hpp
│   │   ├── complex_pow.o
│   │   ├── complex_real.hpp
│   │   ├── complex_real.o
│   │   ├── complex_sinh.hpp
│   │   ├── complex_sinh.o
│   │   ├── complex_sin.hpp
│   │   ├── complex_sin.o
│   │   ├── complex_sqrt.hpp
│   │   ├── complex_sqrt.o
│   │   ├── complex_tanh.hpp
│   │   ├── complex_tanh.o
│   │   ├── complex_tan.hpp
│   │   ├── complex_tan.o
│   │   ├── main.cpp
│   │   ├── main_test
│   │   ├── main_test.cpp
│   │   └── Makefile
│   └── tests
│       ├── catch_amalgamated.cpp
│       ├── catch_amalgamated.hpp
│       └── catch_amalgamated.o
├── Makefile
├── replit.nix
├── result -> /nix/store/ycbh5a0p3ksbynxirbs5j1rzajb901pj-nix-shell
└── tests
    ├── catch_amalgamated.cpp
    ├── catch_amalgamated.hpp
    └── catch_amalgamated.o

```
The directory tree can be generated by the linux **tree** command.  You may need to add this to the REPL NIX environment (install tree.out).

Sources go in [src/](src/), header files in [include/](include/), main programs in [app/](app), and
tests go in [tests/](tests/) (compiled to `unit_tests` by default).

If you add a new executable, say `app/hello.cpp`, you only need to add the following two lines to [CMakeLists.txt](CMakeLists.txt):

```cmake
add_executable(main app/main.cpp)   # Name of exec. and location of file.
target_link_libraries(main PRIVATE ${LIBRARY_NAME})  # Link the executable to lib built from src/*.cpp (if it uses it).
```

You can find the example source code that builds the `main` executable in [app/main.cpp](app/main.cpp) under the `Build` section in [CMakeLists.txt](CMakeLists.txt).
If the executable you made does not use the library in [src/](src), then only the first line is needed.



## Building

Build by making a build directory (i.e. `build/`), run `cmake` in that dir, and then use `make` to build the desired target.

Example:

```bash
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=[Debug | Coverage | Release]
make
./main
make test      # Makes and runs the tests.
make coverage  # Generate a coverage report.
make doc       # Generate html documentation.
```

## .gitignore

The [.gitignore](.gitignore) file is a copy of the [Github C++.gitignore file](https://github.com/LasaACP/komplexkanbanv3-team73/blob/main/.gitignore),
with the addition of ignoring the build directory (`build/`).


## Contributing

Please read [main_test.cpp Blame](https://github.com/LasaACP/komplexkanbanv3-team73/blame/main/src/main_test.cpp) for details on our code of conduct, and the process for submitting pull requests to us.

## Authors

* **Ryan Kellar** - *Writing the README* - [LasaACP-KomplexKanbanv3-team73](https://github.com/LasaACP/komplexkanbanv3-team73/)

See also the list of [contributors to main_test.cpp](https://github.com/LasaACP/komplexkanbanv3-team73/blame/main/src/main_test.cpp) who participated in this project.

## License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details

## Acknowledgments

* Mr. Shockey for bearing with our github issues
* David for creating the Makefile
* Saffron for helping with merge conflicts