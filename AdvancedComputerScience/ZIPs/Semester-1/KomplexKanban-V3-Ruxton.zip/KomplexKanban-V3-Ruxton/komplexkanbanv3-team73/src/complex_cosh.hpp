#include "complex.hpp"
#include <cmath>

complex cosh(const complex z) {
  return complex(
		cosh(z.re) * cos(z.im),
		sinh(z.re) * sin(z.im)
	);
}