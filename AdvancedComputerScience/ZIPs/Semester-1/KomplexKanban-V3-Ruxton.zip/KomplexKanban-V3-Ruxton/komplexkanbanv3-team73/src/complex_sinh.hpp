#include "complex.hpp"
#include <cmath>

complex sinh(const complex z) {
  // https://www.redcrab-software.com/en/Calculator/Algebra/Complex/Sinh
  double x = z.re;
  double y = z.im;

  double resultReal = std::sinh(x) * std::cos(y);
  double resultImaginary = std::cosh(x) * std::sin(y);
  return complex(resultReal, resultImaginary);
}