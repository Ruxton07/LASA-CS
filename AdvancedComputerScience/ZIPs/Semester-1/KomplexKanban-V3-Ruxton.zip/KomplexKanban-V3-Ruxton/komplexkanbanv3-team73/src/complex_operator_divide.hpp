#include "complex.hpp"

complex complex::operator/(const complex other) {
	double test = (other.re*other.re +other.im*other.im);
	if (test == 0) {
		throw std::invalid_argument("can't divide by 0!");
	}
	
	double real = (re * other.re + im * other.im) / (other.re * other.re + other.im * other.im);
  double imag = (im * other.re - re * other.im) / (other.re * other.re + other.im * other.im);
  return complex(real,imag);
}