#include "complex.hpp"
complex complex::operator-(const complex z){
   return complex(re -z.re,  im - z.im);
}