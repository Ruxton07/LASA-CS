#include "complex.hpp"
#include <cmath>

complex pow(double base, const complex exp) {
  // https://www.math.toronto.edu/mathnet/questionCorner/complexexp.html
  double a = base;
  double b = exp.re;
  double c = exp.im;

  double resultReal = std::pow(a, b) * (std::cos(c * log(a)));
  double resultImaginary = std::pow(a, b) * (std::sin(c * log(a)));
  return complex(resultReal, resultImaginary);
}

complex pow(const complex base, double exp) {
  // https://math.stackexchange.com/questions/1397437/formula-for-raising-a-complex-number-to-a-power#1397449
  double a = base.re;
  double b = base.im;
  double r = std::sqrt(a*a + b*b);
  double theta = atan2(b, a);

  double resultReal = std::pow(r, exp) * std::cos(exp * theta);
  double resultImaginary = std::pow(r, exp) * std::sin(exp * theta);  

  return complex(resultReal, resultImaginary);
}

complex pow(const complex base, int exp) {
  return pow(base, (double)exp);
}

complex pow(const complex base, const complex exp) {
  // https://math.stackexchange.com/questions/2518661/complex-exponentiation-raise-complex-number-to-complex-number
  double a = base.re;
  double b = base.im;
  double c = exp.re;
  double d = exp.im;

  double theta = atan2(b, a);
  double firstPart = std::pow((a*a + b*b), c/2) * std::pow(EULER, -d * theta);
  double secondPart = (c * theta) + (0.5 * d * log(a*a + b*b));

  double resultReal = firstPart * std::cos(secondPart);
  double resultImaginary = firstPart * std::sin(secondPart);
  return complex(resultReal, resultImaginary);
}