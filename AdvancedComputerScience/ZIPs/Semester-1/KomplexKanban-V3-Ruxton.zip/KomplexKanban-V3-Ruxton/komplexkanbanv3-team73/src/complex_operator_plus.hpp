#include "complex.hpp"

complex operator+(complex const &a, complex const &b) {
  return complex(a.re + b.re, a.im + b.im);
}

complex complex::operator+(complex const other) {
	return complex(re + other.re, im + other.im);
}
