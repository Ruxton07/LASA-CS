#include "complex.hpp" 
complex operator*(const complex x, const complex y) {
  return complex((x.re *y.re - x.im *y.im), (x.re *y.im + x.im *y.re) );
}

complex complex::operator*(const complex x) {
  return complex( (re *x.re - im *x.im), (re*x.im + im* x.re  ));
  
}