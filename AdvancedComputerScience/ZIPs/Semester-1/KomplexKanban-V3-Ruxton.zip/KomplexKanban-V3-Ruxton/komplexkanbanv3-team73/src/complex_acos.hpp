#include "complex.hpp"
#include <cmath>

complex acos(const complex z) {
  if (z.im == 0) {
    return complex(std::acos(z.re), 0);
  } else {
    return complex(0, -1)*log(sqrt(pow(z, 2)-complex(1,0))+complex(1, 1));
  }
}