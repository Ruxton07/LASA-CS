#include "complex.hpp"

complex log10(const complex z) {
  return log(z) / log(10);
}