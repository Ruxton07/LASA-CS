#include "complex.hpp"
#include <cmath>

complex polar(double mag, double ang) {
  return complex(mag*cos(ang), mag*sin(ang));
}