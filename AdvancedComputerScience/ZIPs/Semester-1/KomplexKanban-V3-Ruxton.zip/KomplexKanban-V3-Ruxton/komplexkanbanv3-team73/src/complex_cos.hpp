#include "complex.hpp"
#include <cmath>

complex cos(const complex z) {
  if (z.im == 0) {
    return std::cos(z.re);
  } else {
    int sign = std::signbit(z.im);
    double alpha = z.re;
    if (sign == 0) {
      return complex(std::cos(alpha)*std::cosh(z.im), 0) - complex(std::sin(alpha), 0)*complex(0, 1)*complex(std::sinh(z.im), 0);
    } else {
      return complex(std::cos(alpha)*std::cosh(z.im), 0) + complex(std::sin(alpha), 0)*complex(0, 1)*complex(std::sinh(z.im), 0);
    }
  }
}