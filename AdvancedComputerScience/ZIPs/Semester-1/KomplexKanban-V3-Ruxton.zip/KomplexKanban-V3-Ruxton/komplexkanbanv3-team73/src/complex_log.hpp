// I idiotically removed this file while debugging so if there are any weird things with github blame or replit that's probably the reason
#include "complex.hpp"
#include <cmath>

complex log(const complex z) {
  if (z.re == 0 && z.im == 0) {
    throw std::invalid_argument("can't take log of 0");
  }
  double real = std::log(abs(z));
  double imag = arg(z);
  //complex fin = real + imag; // if imag has some real component
  return complex(real,imag);
}