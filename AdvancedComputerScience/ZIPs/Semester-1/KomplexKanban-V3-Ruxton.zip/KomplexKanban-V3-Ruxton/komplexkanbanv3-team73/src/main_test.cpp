/*

  Compile with: g++ main.cpp ../src/fac.cpp catch_amalgamated
  Run with ./a.out

*/

//#define CATCH_CONFIG_RUNNER
//#define CATCH_AMALGAMATED_CUSTOM_MAIN
#include "../tests/catch_amalgamated.hpp"
#include "complex.hpp"
#include <iostream>


using namespace std;


#ifdef CATCH_AMALGAMATED_CUSTOM_MAIN

int main(int argc, char *argv[]) {
  // global setup...

  int result = Catch::Session().run(argc, argv);

  // global clean-up...
  cout << "Hello Catch2 Build with custom main()\n";

  return result;
}

#else  // Not CATCH_AMALGAMATED_CUSTOM_MAIN
TEST_CASE("abs", "[abs]")
{
  REQUIRE(abs(complex(1, 0)) == 1);
  REQUIRE(abs(complex(-1, 1)) == sqrt(2));
  REQUIRE(abs(complex(0, -1)) == 1);
  REQUIRE(abs(complex(0, 0)) == 0);
}

TEST_CASE("imag", "[imag]")
{
  REQUIRE(imag(complex(1, 0)) == 0);
  REQUIRE(imag(complex(-1, 1.2)) == 1.2);
  REQUIRE(imag(complex(0, -1.124235246)) == -1.124235246);
  REQUIRE(imag(complex(0, 0)) == 0);
  REQUIRE(imag(complex(1, 256825634)) == 256825634);
}

TEST_CASE("arg", "[arg]")
{
  REQUIRE(arg(complex(1, 0)) == 0);
  REQUIRE(arg(complex(-1, 1.2)) == 2.26553460299159992);
  REQUIRE(arg(complex(0, -1.124235246)) == -1.57079632679489656);
  REQUIRE(arg(complex(0, 0)) == 0);
  REQUIRE(arg(complex(1, 256825634)) == 1.57079632290120430);
}

TEST_CASE("norm", "[norm]")
{
  REQUIRE(norm(complex(1, 0)) == 1);
  REQUIRE(norm(complex(-1, 1.2)) == 2.44);
  REQUIRE(norm(complex(0, -1.124235246)) == 1.2639048883486805);
  REQUIRE(norm(complex(0, 0)) == 0);
  REQUIRE(norm(complex(1, 4521)) == 20439442.0);
}

TEST_CASE("conj", "[conj]")
{
  REQUIRE(conj(complex(1, 0)) == complex(1, 0));
  REQUIRE(conj(complex(-1, 1.2)) == complex(-1, -1.2));
  REQUIRE(conj(complex(0, -1.124235246)) == complex(0, 1.124235246));
  REQUIRE(conj(complex(0, 0)) == complex(0, 0));
  REQUIRE(conj(complex(1, 4521)) == complex(1, -4521));
}

TEST_CASE("operators", "[operators]") {
  complex a(1,1);
  complex b(1,1);
  complex c(2,4);

  REQUIRE((a == b) == true);
  REQUIRE((a == c) == false);

  REQUIRE((a + b) == complex(2,2));
  REQUIRE ((a-b) == complex(0,0));
  REQUIRE((c-b) == complex(1,3));
  REQUIRE((c-a)  == complex(1,3));

  REQUIRE((b*a) == complex(0,2));
  REQUIRE ((c*a) == complex(-2,6));

  complex a2(1,1);
  complex b2(1,1);
  complex c2(2,4);
  a2-= b2;
  REQUIRE((a2) == complex(0,0));
  c2-= b2;
  a2+= b2;
  REQUIRE((a2) == complex(1,1));
  REQUIRE((c2) == complex(1,3));
  b2*= b2;
  REQUIRE((b2) == complex(0,2));
  a2*=a2;
  REQUIRE((a2) == complex(0,2));

  b2/=a2;
  REQUIRE((b2) == complex(1,0));
  REQUIRE((c / a) == complex(3,1));
  a += b;
  REQUIRE(a == complex(2,2));
}

TEST_CASE("real", "[real]") {
  complex a(4,6);
  complex b(-2,5);
  REQUIRE(real(a) == 4);
  REQUIRE(real(b) == -2);
}

TEST_CASE("tanh", "[tanh]") {
  REQUIRE(tanh(complex(1, 1)) == complex(1.0839233273386946, 0.2717525853195118));
  REQUIRE(tanh(complex(4,0))  == complex(0.999329299739,0));
}

TEST_CASE("sinh", "[sinh]") {
  REQUIRE(sinh(complex(-2.0, 0.0)) == complex(-3.626860407847018, 0.0));
  REQUIRE(sinh(complex(-1.0, 0.0)) == complex(-1.1752011936438014, 0.0));
  REQUIRE(sinh(complex(-2.0, -2.0)) == complex(1.5093064853236156, -3.4209548611170133));
  REQUIRE(sinh(complex(-1.0, -1.0)) == complex(-0.6349639147847361, -1.2984575814159773));
  REQUIRE(sinh(complex(0.0, -2.0)) == complex(0.0, -0.9092974268256817));
  REQUIRE(sinh(complex(1.0, 0.0)) == complex(1.1752011936438014, 0.0));
  REQUIRE(sinh(complex(2.0, -2.0)) == complex(-1.5093064853236156, -3.4209548611170133));
  REQUIRE(sinh(complex(1.0, 1.0)) == complex(0.6349639147847361, 1.2984575814159773));
}

TEST_CASE("pow", "[pow]") {
  REQUIRE(pow(complex(1.0, 1.0), complex(-2.0, 1.0)) == complex(0.0774358762321234, -0.2144145031471839));
  REQUIRE(pow(complex(-2.0, 1.0), 10) == complex(-237.0, 3116));
  REQUIRE(pow(complex(-2.0, 1.0), 6.4) == complex(-24.051325217870932, -170.7809314522551));
  REQUIRE(pow(complex(-2.4, 3.6), 6.4) == complex(3717.1370114235665, 11184.835038113313));
  REQUIRE(pow(6.4, complex(-2.0, 1.0)) == complex(-0.0068759483200081266, 0.023425793101931117));
}

TEST_CASE("exp", "[exp]") {
  REQUIRE(exp(complex(1,0)) == (complex(EULER, 0)));
  REQUIRE(exp(complex(2,0)) == (complex(EULER*EULER, 0)));
  REQUIRE(exp(complex(0,1)) == (complex(0.5403023058681397174009366074, 0.841470984807896506)));
  REQUIRE(exp(complex(-1,-1)) == (complex(0.1987661103464129406288, -0.3095598756311219844391)));
}

TEST_CASE("acos", "[acos]") {
  REQUIRE(acos(complex(1, 0)) == (complex(0, 0)));
  REQUIRE(acos(complex(-1, 0)) == (complex(PI, 0)));
  REQUIRE(acos(complex(1, 1)) == (complex(0.90455689430238136, -1.0612750619050356520330189)));
  REQUIRE(acos(complex(0, 0)) == (complex((PI / 2), 0)));
}

TEST_CASE("asin", "[asin]") {
  REQUIRE(asin(complex(1, 0)) == (complex((PI/2), 0)));
  REQUIRE(asin(complex(-1, 0)) == (complex((-(PI/2)), 0)));
  REQUIRE(asin(complex(1, 1)) == (complex(0.666239432492515255, 1.061275061905035652)));
  REQUIRE(asin(complex(0, -1)) == (complex(0, -0.881373587019543025232609)));
  REQUIRE(asin(complex(0, 0)) == (complex(0, 0)));
}

TEST_CASE("atan", "[atan]") {
  REQUIRE(atan(complex(1, 0)) == (complex((PI / 4), 0)));
  REQUIRE(atan(complex(-1, 0)) == (complex((-(PI / 4)), 0)));
  REQUIRE(atan(complex(1, 1)) == (complex(1.0172219678978512677227889615504, 0.4023594781085250936501)));
  REQUIRE(atan(complex(-1, -1)) == (complex(-1.0172219678978513677227889615504, -0.4023594781085250936501)));
  REQUIRE(atan(complex(0, 0)) == (complex(0, 0)));
}

TEST_CASE("cos", "[cos]") {
  REQUIRE(cos(complex(PI, 0)) == (complex(-1, 0)));
  REQUIRE(cos(complex(0, 0)) == (complex(1, 0)));
  REQUIRE(cos(complex((PI / 2), 0)) == (complex(0, 0)));
  REQUIRE(cos(complex(-(PI / 2), 0)) == (complex(0, 0)));
}

TEST_CASE("sin", "[sin]") {
  REQUIRE(sin(complex(PI, 0)) == (complex(0, 0)));
  REQUIRE(sin(complex(0, 0)) == (complex(0, 0)));
  REQUIRE(sin(complex((PI / 2), 0)) == (complex(1, 0)));
  REQUIRE(sin(complex(-(PI / 2), 0)) == (complex(-1, 0)));
}

TEST_CASE("tan", "[tan]") {
  REQUIRE(tan(complex(0, 0)) == complex(0, 0));
  REQUIRE(tan(complex(PI, 0)) == complex(0, 0));
  REQUIRE(tan(complex(1.0172219678978512677227889615504, 0.4023594781085250936501)) == complex(1, 1));
  REQUIRE(tan(complex((PI / 4), 0)) == complex(1, 0));
  REQUIRE(tan(complex(-1.0172219678978513677227889615504, -0.4023594781085250936501)) == (complex(-1, 1)));
}

TEST_CASE("sqrt", "[sqrt]") {
  REQUIRE(sqrt(complex(2.0, 4.0)) == complex(1.7989074399478673, 1.1117859405028423));
  REQUIRE(sqrt(complex(-1, 0)) == complex(0.0, 1.0));
  REQUIRE(sqrt(complex(0, -1)) == complex(0.7071067811865476, -0.7071067811865475));
  REQUIRE(sqrt(complex(0, 0)) == complex(0.0, 0.0));
}

TEST_CASE("log10", "[log10]") {
	CHECK_THROWS(log10(complex(0, 0)) == 0); // TODO throw error
	REQUIRE(log10(complex(1, -1)) == complex(0.15051499783199057, -0.3410940884604603));
	REQUIRE(log10(complex(43524311.244, -123.123)) == complex(7.638731907297208, -0.00000122854));
	REQUIRE(log10(complex(0.001, 0.001)) == complex(-2.849485002168009, 0.3410940884604603));
	REQUIRE(log10(complex(1941.5193, 19475022.672845)) == complex(7.289477974109208, 0.6821448808934977));
}

TEST_CASE("polar", "[polar]") {
	REQUIRE(polar(0, 0) == complex(0, 0));
	REQUIRE(polar(100, -234) == complex(4.86335005389691144, -99.88166912028081867));
	REQUIRE(polar(-123.25, 40.12) == complex(92.60277927408520782, -81.33441934823814279));
	REQUIRE(polar(-0.424, -0.9993) == complex(-0.22933787012938486, 0.35662324843526033));
	REQUIRE(polar(500, 0) == complex(500.0, 0.0));
}

TEST_CASE("log", "[log]") { // I have no idea what the edge cases are for this --Max Bentley
  REQUIRE(log(complex(1,1)) == complex(0.34657359027997264, 0.7853981633974483));
  REQUIRE(log(complex(-3,1)) == complex(1.151292546497023, 2.819842099193151));
  REQUIRE(log(complex(-3,0)) == complex(1.09861228867,PI));
  CHECK_THROWS(log(complex(0,0))); // throws error (good)
}

TEST_CASE("cosh", "[cosh]") {
	REQUIRE(cosh(complex(0, 0)) == complex(1, 0));
	REQUIRE(cosh(complex(1.739, -139)) == complex(2.1062715172408493, -1.9197726155527681));
	REQUIRE(cosh(complex(0.001, 0.001)) == complex(0.99999999999983324450, 0.000000999999999999988943319797519981850797421429888345301151275634765625)); // floating point pain
	REQUIRE(cosh(complex(100, 100)) == complex(11590070711540410580611617889150374032441344.0, -6805850799469298930869738076333889141342208.0));
}
#endif // ifndef CATCH_AMALGAMATED_CUSTOM_MAIN