#include "complex.hpp"

double imag(const complex c) {
	return c.im; // STUB
}