#include "complex.hpp"
#include <cmath>

bool operator==(const complex& a, const complex& b){
  return std::round(a.re * 100000000) == std::round(b.re * 100000000)
					&& round(a.im * 100000000) == round(b.im * 100000000);
}