#include "complex.hpp"

complex exp(const complex z) {
  complex res = pow(EULER, z);
  return complex(res.re, res.im);
}