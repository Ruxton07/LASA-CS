#include "complex.hpp"

complex complex::operator-=(const complex x){
  re -= x.re;
  im-= x.im;
   return complex(re, im );
}