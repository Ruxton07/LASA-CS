#include "complex.hpp"
#include <iomanip>

std::ostream& operator<<(std::ostream& output, const complex& z) {
  output << std::setw(24) << std::fixed << "(" << z.re << " + " << z.im << "i)" << std::defaultfloat;
  return output;
}