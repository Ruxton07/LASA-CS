#ifndef COMPLEX_HPP
#define COMPLEX_HPP

#include <iostream>

#define PI 3.1415926538979323846
#define EULER 2.71828182845904523536


class complex {
public:
	double re, im;
	complex() {re=0.0; im=0.0;}
	complex(double r, double i = 0.0) {re=r; im=i;}

	complex operator-=(const complex x);
	complex operator+=(const complex x);
complex operator/=(const complex x);
complex operator*=(const complex x);

	complex operator-(const complex x);
	complex operator/(const complex x);
	complex operator*(const complex x);
  complex operator+(const complex x);
};

bool operator==(const complex& a, const complex& b);
complex operator+ (const complex& a, const complex& b);

std::ostream& operator<<(std::ostream& output, const complex& z);


double abs(const complex c);
complex acos(const complex x);
double arg(const complex c);
complex asin(const complex x);
complex atan(const complex z);
complex conj(const complex c);
complex cosh(const complex z);
complex cos(const complex x);
complex exp(const complex z);
double imag(const complex c);
complex log10(const complex z);
complex log(const complex z);
double norm(const complex c);
complex polar(double mag, double ang=0.0);
complex pow(double base, const complex exp);
complex pow(const complex base, int exp);
complex pow(const complex base, double exp);
complex pow(const complex base, const complex exp);
double real(const complex x);
complex sin(const complex x);
complex sinh(const complex z);
complex sqrt(const complex z);
complex tanh(const complex a);
complex tan(const complex z);
#endif

