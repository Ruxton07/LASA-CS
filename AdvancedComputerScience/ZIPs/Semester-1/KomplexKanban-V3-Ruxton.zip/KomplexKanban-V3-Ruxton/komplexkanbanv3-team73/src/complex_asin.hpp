#include "complex.hpp"
#include <cmath>

complex asin(const complex z) {
  if (z.im == 0) {
    return complex(std::asin(z.re), 0);
  } else {
    return complex(0, -1)*log(sqrt(complex(1, 0)-pow(z, 2))+complex(z.re, z.im)*complex(0, 1));
  }
}