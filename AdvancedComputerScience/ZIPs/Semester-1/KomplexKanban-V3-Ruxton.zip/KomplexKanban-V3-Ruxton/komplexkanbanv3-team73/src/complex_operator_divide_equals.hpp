#include "complex.hpp"

complex complex::operator/=(const complex x) {
	double test = (x.re*x.re +x.im*x.im);
	if (test == 0) {
		throw std::invalid_argument("can't divide by 0!");
	}
	double r = (re*x.re+ im *x.im)/(x.re*x.re +x.im*x.im); 
	double i = (im*x.re - re*x.im) / ( x.re *x.re + x.im *x.im);

	re = r;
	im = i;
		return complex(re , im);
}