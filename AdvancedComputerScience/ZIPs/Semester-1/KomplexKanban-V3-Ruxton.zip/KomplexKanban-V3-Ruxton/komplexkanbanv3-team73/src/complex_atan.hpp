#include "complex.hpp"
#include <cmath>

complex atan(const complex z) {
  if (z.im == 0) {
    return complex(std::atan(z.re), 0);
  } else {
    return (complex(-0.5, 0)*complex(0, 1))*log((complex(1,0)+complex(0,1)*complex(z.re, z.im))/(complex(1,0)-complex(0,1)*complex(z.re, z.im)));
  }
}