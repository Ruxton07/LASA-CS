#include "complex.hpp"

complex tan(const complex z) {
  return sin(z) / cos(z);
}