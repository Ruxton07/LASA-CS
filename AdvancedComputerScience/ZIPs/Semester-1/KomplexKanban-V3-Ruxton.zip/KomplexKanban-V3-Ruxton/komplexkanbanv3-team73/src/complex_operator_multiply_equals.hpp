#include "complex.hpp"
complex complex::operator*=(const complex x){
  double r = re*x.re - im*x.im;
  double i = re*x.im + im*x.re;
	re = r;
	im = i;
  return complex( re, im);
}