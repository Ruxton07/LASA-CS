#include "complex.hpp"

complex conj(const complex c) {
	return complex(c.re, -c.im);
}