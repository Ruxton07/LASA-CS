#include "complex.hpp"

double real(const complex x) {
  return x.re;
}