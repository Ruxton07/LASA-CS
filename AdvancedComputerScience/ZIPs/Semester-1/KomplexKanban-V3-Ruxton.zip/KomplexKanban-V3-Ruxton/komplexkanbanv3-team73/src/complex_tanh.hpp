#include "complex.hpp"

complex tanh(const complex value) {
  if(cosh(value ) == complex(0,0 )){
    throw std::invalid_argument("Cannot divide by 0!");
  }
  return sinh(value) / cosh(value); //(sinh(value.re*2) +sin(value.im*2)) /( cosh(value.re*2) + cos(value.im*2)); 
}