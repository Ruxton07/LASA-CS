#include "complex.hpp"
#include <cmath>

complex sqrt(const complex z) {
  // https://math.stackexchange.com/questions/44406/how-do-i-get-the-square-root-of-a-complex-number
  double resultReal = std::sqrt((z.re + std::sqrt(z.re * z.re + z.im * z.im))/2);
  double dOverD = (z.im != 0) ? (z.im / std::abs(z.im)) : 1;
  double resultImaginary = dOverD * std::sqrt((-z.re + std::sqrt(z.re * z.re + z.im * z.im))/2);

  return complex(resultReal, resultImaginary);
}