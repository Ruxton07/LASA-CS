#include "complex.hpp"
#include <cmath>

double abs(const complex c) {
	return sqrt((c.re * c.re) + (c.im * c.im));
}