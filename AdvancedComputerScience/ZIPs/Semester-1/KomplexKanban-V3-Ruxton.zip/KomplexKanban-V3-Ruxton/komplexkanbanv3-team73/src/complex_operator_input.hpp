#include "complex.hpp"


std::istream& operator>>(std::istream& s, complex& z) {
  double re, im;
  s >> re >> im;
  z.re = re;
  z.im = im;
  return s;
}