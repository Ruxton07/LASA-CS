#include "complex.hpp"
#include <cmath>

complex sin(const complex z) {
  if (z.im == 0) {
    return std::sin(z.re);
  } else {
    int sign = std::signbit(z.im);
    double alpha = z.re;
    if (sign == 0) {
      return complex(std::sin(alpha)*std::cosh(z.im), 0) + 
complex(std::cos(alpha), 0)*complex(0, 1)*complex(std::sinh(z.im), 0);
    } else {
      return complex(std::sin(alpha)*std::cosh(z.im), 0) - 
        complex(std::cos(alpha), 0)*complex(0, 1)*complex(std::sinh(z.im), 0);
    }
  }
}