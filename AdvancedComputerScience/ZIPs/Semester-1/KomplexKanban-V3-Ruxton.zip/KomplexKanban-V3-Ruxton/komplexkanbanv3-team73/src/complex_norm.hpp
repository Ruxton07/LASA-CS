#include "complex.hpp"

double norm(const complex c) {
	return (c.re * c.re) + (c.im * c.im);
}