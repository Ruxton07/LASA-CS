#include "complex.hpp"
#include <cmath>

double arg(const complex c) {
	return atan2(c.im, c.re);
}