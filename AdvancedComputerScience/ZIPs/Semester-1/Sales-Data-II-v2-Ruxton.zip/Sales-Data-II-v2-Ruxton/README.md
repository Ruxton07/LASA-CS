Instructions at

https://docs.google.com/document/d/1ElhmeHzcfCxpUF9xkoVQuk3xRY3PCpnVL8e0Nv5yP4U/edit?usp=sharing

Your output in REPL.IT should not have spaces.

