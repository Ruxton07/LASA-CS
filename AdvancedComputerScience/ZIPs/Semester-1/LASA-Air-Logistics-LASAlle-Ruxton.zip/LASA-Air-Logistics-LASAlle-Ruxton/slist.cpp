#include "slist.h"
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
// Class Library File

// Constructor
Node::Node() {
  this->data = NULL;
  this->next = NULL;
}

Node::Node(Airport *dat) {
  this->data = dat;
  this->next = NULL;
}

LinkList::LinkList() { // Serving as a default constructor
  head = new Node(NULL);
  elements = 0;
}

// Destructor
LinkList::~LinkList() {
  Node *current = head;
  while (current != NULL) {
    Node *next = current->next;
    delete current;
    current = next;
  }
  elements = 0;
}

// add(value)				//Adds a new value to the end of this
// list.
void LinkList::add(Airport *newAirport) {
  if (head->next == NULL) {
    Node *addNode = new Node(newAirport);
    head->next = addNode;
  } else {
    Node *current = head->next;
    while (current->next != NULL) {
      current = current->next;
    }
    Node *addNode = new Node(newAirport);
    current->next = addNode;
  }
  elements++;
}

// clear()					//Removes all elements from this
// list.
void LinkList::clear() {
  for (int i = 0; i < elements; i++) {
    delete head;
    head = head->next;
  }
  delete head;
  elements = 0;
}

// equals(list)				//Returns true if the two lists contain
// the same elements in the same order.
bool LinkList::equals(LinkList list) {
  bool state = true;
  Node *tempHeadThis = head->next;
  Node *tempHeadThat = list.head->next;
  for (int i = 0; i < elements; i++) {
    if (tempHeadThis->data == tempHeadThat->data) {
      tempHeadThis = tempHeadThis->next;
      tempHeadThat = tempHeadThat->next;
    } else {
      state = false;
      break;
    }
  }
  return state;
}

// get(index)				//Returns the element at the specified
// index in this list.
Airport *LinkList::get(int index) {
  Node *cNode = head->next;
  for (int i = 0; i <= index; i++) {
    if (cNode->next == NULL) {
      break;
    }
    cNode = cNode->next;
  }
  return cNode->data;
  
}

Node *LinkList::getNode(int index) {
  Node *cNode = head->next;
  for (int i = 0; i <= index; i++) {
    cNode = cNode->next;
    if (cNode == NULL) {
      break;
    }
  }
  return cNode;
}

// insert(index, value)		//Inserts the element into this list before
// the specified index.
void LinkList::insert(int index, Node *newNode) {
  Node *current = head;
  for (int i = 0; i < index - 1; i++) {
    current = current->next;
  }
  newNode->next = current->next;
  current->next = newNode;
  elements++;
}

// exchg(index1, index2)		//Switches the payload data of specified
// indexes.
void LinkList::exchg(int index1, int index2) {
  Node *node1 = getNode(index1);
  Node *node2 = getNode(index2);
  Node *temp = node1;
  temp->data = node1->data;
  node1->data = node2->data;
  node2->data = temp->data;
  delete temp;
}

// swap(index1,index2)		//Swaps node located at index1 with node
// at index2
void LinkList::swap(int index1, int index2) {
  Node *node1 = getNode(index1);
  Node *node2 = getNode(index2);
  Node *temp = node1;
  temp = node1;
  node1 = node2;
  node2 = temp;
  delete temp;
}

// isEmpty()				//Returns true if this list contains no
// elements.
bool LinkList::isEmpty() { return elements == 0; }

// remove(index)			//Removes the element at the specified
// index from this list.
void LinkList::remove(int index) {
  Node *current = head;
  for (int i = 0; i < index - 1; i++) {
    current = current->next;
  }
  Node *temp = current->next;
  current->next = current->next->next;
  delete temp;
  elements--;
}

// set(index, value)		//Replaces the element at the specified index in
// this list with a new value.
void LinkList::set(int index, Node *newNode) {
  Node *current = head;
  for (int i = 0; i < index - 1; i++) {
    current = current->next;
  }
  newNode->next = current->next->next;
  Node *temp = current->next;
  delete temp;
  current->next = newNode;
}

// size()					//Returns the number of elements
// in this list.
int LinkList::size() { return elements; }

// DO NOT IMPLEMENT >>> subList(start, length)	//Returns a new list
// containing elements from a sub-range of this list.

// DO NOT IMPLEMENT >>> toString()				//Converts the
// list to a printable string representation.