
//
//  main.cpp
//  LLTemplate
//
//  Created by James Shockey on 12/6/16.
//  Copyright © 2016 James Shockey. All rights reserved.
// yippeeeeee so cool

/*
 *
 *	Linked List lab.
 *	- Build a library for singly linked list.
 *	- Replace the airport array in main with a Linked List.
 *  - sort the array.
 *
 */

#include "slist.h"
#include <cmath>
#include <fstream>
#include <iostream>

using namespace std;

void simpleSortTotal(Airport *s[], int c);
double distanceEarth(double lat1d, double lon1d, double lat2d, double lon2d);
double km2miles(double km);
void linklistSort(LinkList *arr);

int main() {
  ifstream infile;
  int i = 0;
  char cNum[100];
  LinkList *airportArr = new LinkList(); // Replace array with Linked List
  int airportCount;
  LinkList *a = new LinkList();
  // 33500
  infile.open("airports.csv", ifstream::in);
  Airport *AUSBERGSTROM = new Airport();
  if (infile.is_open()) {
    int c = 0;
    char dump[200];
    infile.getline(dump, 3000, '\n');
    while (infile.good()) {
      Airport *cAP = new Airport();
      infile.getline(cAP->code, 3000, ',');
      infile.getline(cNum, 3000, ',');
      cAP->latitude = atof(cNum);
      infile.getline(cNum, 3000, ',');
      cAP->longitude = atof(cNum);
      infile.getline(dump, 3000, '\n');
      airportArr->add(cAP);
      if (!(c % 1000))
        cout << airportArr->get(c)->code
             << " long: " << airportArr->get(c)->longitude
             << " lat: " << airportArr->get(c)->latitude << endl;
      /*
      if (!(c % 1000))
      {
          cout << airportArr->get(c)->code << " long: " <<
      airportArr->get(c)->longitude
      << " lat: " << airportArr->get(c)->latitude <<  endl; cout <<
      airportArr->get(c+1)->code << endl; //" long: " <<
      airportArr->get(c+1)->longitude
      << " lat: " << airportArr->get(c+1)->latitude <<  endl;
      }
      */

      i++;
      c++;
    }
    airportCount = c - 1;
    infile.close();
    for (int c = 0; c < airportCount; c++)
      if (!(c % 1000)) {
        cout << airportArr->get(c)->code
             << " long: " << airportArr->get(c)->longitude
             << " lat: " << airportArr->get(c)->latitude << endl;
        cout << airportArr->get(c + 1)->code
             << " long: " << airportArr->get(c + 1)->longitude
             << " lat: " << airportArr->get(c + 1)->latitude << endl;
        cout << "Distance between " << airportArr->get(c)->code << " and "
             << airportArr->get(c + 1)->code << " is "
             << distanceEarth(airportArr->get(c)->longitude,
                              airportArr->get(c)->latitude,
                              airportArr->get(c + 1)->longitude,
                              airportArr->get(c + 1)->latitude)
             << endl;
      }

  } else {
    cout << "Error opening file";
  }

  AUSBERGSTROM->latitude = 30.1944;
  AUSBERGSTROM->longitude = 97.6700;

  double largestDist = -100000.0;
  Airport *largestDistAP;
  LinkList *miles100 = new LinkList();
  for (int c = 0; c < airportCount; c++) {
    double cDist = distanceEarth(
        AUSBERGSTROM->latitude, AUSBERGSTROM->longitude,
        airportArr->get(c)->latitude, airportArr->get(c)->longitude);
    if (cDist > largestDist) {
      largestDist = cDist;
      largestDistAP = airportArr->get(c);
    }
    double distmiles = km2miles(cDist);
    if (distmiles <= 100.0 && airportArr->get(c)->latitude != 30.1944 &&
        airportArr->get(c)->latitude != 97.6700) {
      miles100->add(airportArr->get(c));
    }
  }
  cout << "\n\n" << endl;
  cout << "LARGEST AIRPORT DISTANCE: " << largestDistAP->code << "\n" << endl;
  cout << "Airports within 100 miles of Austin-Bergstrom: [";
  for (int c = 0; c < miles100->elements; c++) {
    cout << miles100->get(c)->code << ", ";
  }
  cout << "]" << endl;
  linklistSort(airportArr);
  for (int c = 0; c < airportCount; c++) {
    cout << airportArr->get(c)->code << " dEarth: " << distanceEarth(
        AUSBERGSTROM->latitude, AUSBERGSTROM->longitude,
        airportArr->get(c)->latitude, airportArr->get(c)->longitude);
  }
}

#define pi 3.14159265358979323846
#define earthRadiusKm 6371.0

// This function converts decimal degrees to radians
double deg2rad(double deg) { return (deg * pi / 180); }

//  This function converts radians to decimal degrees
double rad2deg(double rad) { return (rad * 180 / pi); }

/**
 * Returns the distance between two points on the Earth.
 * Direct translation from http://en.wikipedia.org/wiki/Haversine_formula
 * @param lat1d Latitude of the first point in degrees
 * @param lon1d Longitude of the first point in degrees
 * @param lat2d Latitude of the second point in degrees
 * @param lon2d Longitude of the second point in degrees
 * @return The distance between the two points in kilometers
 */
double distanceEarth(double lat1d, double lon1d, double lat2d, double lon2d) {
  double lat1r, lon1r, lat2r, lon2r, u, v;
  lat1r = deg2rad(lat1d);
  lon1r = deg2rad(lon1d);
  lat2r = deg2rad(lat2d);
  lon2r = deg2rad(lon2d);
  u = sin((lat2r - lat1r) / 2);
  v = sin((lon2r - lon1r) / 2);
  return 2.0 * earthRadiusKm *
         asin(sqrt(u * u + cos(lat1r) * cos(lat2r) * v * v));
}

double km2miles(double km) { return (km * 0.6213712); }

void
linklistSort(LinkList *airportArray) { // I'm using bubble sort for linkedlists
  LinkList *sorted = new LinkList();
  Node *temp = new Node();

  Airport *AUSBERGSTROM = new Airport();
  AUSBERGSTROM->latitude = 30.1944;
  AUSBERGSTROM->longitude = 97.6700;

  for (int i = 0; i < airportArray->elements; i++) {
    for (int j = 0; j < airportArray->elements - 1 - i; j++) {
      double c1Distance = distanceEarth(
          AUSBERGSTROM->latitude, AUSBERGSTROM->longitude,
          airportArray->get(j)->latitude, airportArray->get(j)->longitude);
      double c2Distance =
          distanceEarth(AUSBERGSTROM->latitude, AUSBERGSTROM->longitude,
                        airportArray->get(j + 1)->latitude,
                        airportArray->get(j + 1)->longitude);
      if (c1Distance > c2Distance) {
        temp = airportArray->getNode(j);
        airportArray->set(j, airportArray->getNode(j+1));
        airportArray->set(j+1, temp);
      }
    }
  }
}