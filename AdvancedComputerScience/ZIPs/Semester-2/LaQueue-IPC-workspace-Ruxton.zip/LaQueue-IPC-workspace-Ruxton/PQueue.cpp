/*
 * LaQueue
 * 
 * 
 * This is part of a series of labs for the Liberal Arts and Science Academy.
 * The series of labs provides a mockup of an POSIX Operating System
 * referred to as LA(SA)nix or LAnix.
 *  
 * (c) copyright 2018, James Shockey - all rights reserved
 * 
 * */

#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include "PQueue.h"



/*
 * Class Priority Queue
 */


/*
* Insert into Priority Queue
*/
void PQueue::push(void *item, int priority)
{
	node *temp = new node();
  temp->data = item;
  temp->priority = priority;
  if (front != NULL) {
    node *cNode = front;
    if (temp->priority < front->priority) {
      temp->link = front;
      front = temp;
    }
    while (cNode->priority < temp->priority && cNode->link != NULL) {
      cNode = cNode->link;
    }
    node *nextNode = new node();
    nextNode = cNode->link;
    cNode->link = temp;
    temp->link = nextNode;
  } else {
    front = temp;
  }
}

/*
 * Show top item in Queue
 */
void* PQueue::top()
{
	if (front != NULL)
    return front->data;
  else
    return front;
}
/*
 * Delete from Priority Queue
 */
void PQueue::pop()
{
	/* Your code here */
  if (front == NULL) {
    return;
  } else {
    node* temp = front;
    front = front->link;
    delete temp;
  }
}

/*
 * Print Priority Queue
 */
void PQueue::display()
{
	node* cNode = front;
  while (cNode != NULL) {
    /* Use the following out command for the data */
    std::cout<<cNode->priority<<" "<<(char*)cNode->data<<std::endl;
  }
}