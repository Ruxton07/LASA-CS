Complete the B_TREE_SPLIT_CHILD function based on the algorithm shown in the presentation.


In main.cpp add code to where the comment ">>>>   YOUR CODE GOES HERE    <<<<" is located.

void B_TREE_SPLIT_CHILD (node* node1,int index, node* node2)
{
  //
  //    >>>>   YOUR CODE GOES HERE    <<<<
  //
}

