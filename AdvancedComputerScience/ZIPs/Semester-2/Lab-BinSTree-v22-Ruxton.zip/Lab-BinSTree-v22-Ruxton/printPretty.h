

void printPretty(node *root, int level, int indentSpace, std::ostream& out);
