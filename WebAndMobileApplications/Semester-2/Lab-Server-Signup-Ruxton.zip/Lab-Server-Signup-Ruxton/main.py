# Lab instructions on BLE



import flask as fk
import re
import random
import logging
import html

def valid_user(user):
    try:
        ret = re.search("^[\w-]{3,20}$", user).group(0) == user
    except AttributeError:
        ret = False
    return ret


def valid_pass(password):
    try:
      ret = re.search("^.{3,20}$", password).group(0) == password
    except AttributeError:
      ret = False
    return ret


def valid_email(email):
    try:
      ret = re.search("^\w+@\w+\.\w+$", email).group(0) == email
    except AttributeError:
      ret = False
    return ret

def valid_entry(user="", password="", vpassword="", email=""):
    return (valid_user(user) and valid_pass(password) and valid_pass(vpassword) and valid_email(email) and password == vpassword)
  
success = """
<!DOCTYPE HTML>
<html>	
	<h1 style="color: black">Welcome, %(username)s!</h1>
  <img src="https://media.giphy.com/media/JIX9t2j0ZTN9S/gifs/welcome-to-the-jungle-jungle-parks-JIX9t2j0ZTN9S/giphy.gif" alt="Cat spamming keyboard">
</html>
"""

form = """
<!DOCTYPE HTML>
<html>
<h1 style="color: red"><strong>Signup</strong></h1><br>
<style>
label {
  color: blue;
}
</style>
<div>
<form method="post" action="/submitted">
<div class = "msverma">
<label>Username</label>
<div class="sector">
<input type="text" name="user" value="%(user)s">
<div class="error" style="color: red">%(errorU)s</div>
</div>
</div>
<div class = "msverma">
<label>Password</label>
<div class="sector">
<input type="password" name="password" value="%(password)s">
<div class="error" style="color: red">%(errorP)s</div>
</div>
</div>
<div class = "msverma">
<label>Verify Password</label>
<div class="sector">
<input type="password" name="vpassword" value="%(vpassword)s">
<div></div>
</div>
</div>
<div class = "msverma">
<label>Email (optional)</label>
<div class="sector">
<input type="text" name="email" value="%(email)s">
<div class="error" style="color: red">%(errorE)s</div>
</div>
</div>
<input type="submit" value="Submit Query">
</form>
</div>
<style>
div {
  display: flex;
  flex-direction: column;
}
.sector {
  display: flex;
  flex-direction: row;
  width: 400px;
  height: 20px;
}
.msverma {
  display: flex;
  flex-direction: row;
  width: 512px;
  justify-content: space-between;
}
.error {
  width: 350px;
}
</style>
</html>
"""

def write_form(user="", password="", vpassword="", email="", errorU="", errorP="", errorE=""):
  return form % {"user": user, "password": password, "vpassword": vpassword, "email": email, "errorU": errorU, "errorP": errorP, "errorE": errorE}

app = fk.Flask(
    __name__,
    static_folder="stylesheets"
)

@app.route('/', methods=["GET", "POST"])
def root():
	return write_form()

@app.route('/submitted', methods=['POST'])
def submitted():
  print("submitting")
  logging.info("******TestForm " +  str(fk.request.method) + "******")
  print("1")
  user = html.escape(fk.request.form["user"])
  print("2")
  logging.info("month=" + str(user) + " type=" + str(type(user)))
  password = html.escape(fk.request.form["password"])
  print("3")
  logging.info("day=" + str(password) + " type=" + str(type(password)))
  vpassword = html.escape(fk.request.form["vpassword"])
  print("4")
  logging.info("year=" + str(vpassword) + " type=" + str(type(vpassword)))
  email = html.escape(fk.request.form["email"])
  print("5")
  logging.info("email=" + str(email) + " type=" + str(type(email)))
  print(valid_user(user))
  print(valid_pass(password))
  print(password==vpassword)
  print(valid_email(email))
  print(email == "")
  if valid_user(user) and valid_pass(password) and password==vpassword and (valid_email(email) or email == ""):
    print("6")
    return fk.redirect(fk.url_for('welcome'), code=308)
  print("7")
  return write_form(user, password, vpassword, email, "&nbsp;That's not a valid username." if not valid_user(user) else "", "&nbsp;That's not a valid password." if not valid_pass(password) else ("&nbsp;Passwords do not match." if password!=vpassword else ""), "&nbsp;That's not a valid email." if not valid_email(email) and email!="" else "")
      
@app.route('/welcome', methods=["POST"])
def welcome():
    username = fk.request.form['user']
    logging.info("username=" + str(username) + " type=" + str(type(username)))
    return (success % {"username": username})

if __name__ == "__main__":
  app.run(host='0.0.0.0', port=random.randint(2000, 9000))