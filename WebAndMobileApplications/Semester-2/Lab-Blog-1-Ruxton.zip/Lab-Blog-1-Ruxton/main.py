# Lab: BLOG-1
import flask as fk
import re
import logging
import sqlite3
import datetime
from dateutil import tz

app = fk.Flask(
    __name__,
    static_folder="stylesheets"
)

def to_cst(tzutcobj):
  return tzutcobj.astimezone(tz.tzlocal())
  
print(to_cst(datetime.datetime.now(tz=tz.tzutc())))

def write_posts(posts):
  print("Redirecting to posts.html...")
  return fk.render_template("posts.html", posts=posts)
  
def write_perma_post():
  conn = get_connection()
  cur = conn.cursor()
  
def get_connection():
    return sqlite3.connect("blogbosts.db")

def get_posts():
  conn = get_connection()
  cur = conn.cursor()
  return cur.execute("SELECT * FROM posts "
    "ORDER BY create_date DESC LIMIT 10").fetchall()

def get_post_by_id(id):
  conn = get_connection()
  cur = conn.cursor()
  return cur.execute("SELECT * FROM posts WHERE id=" + id).fetchall()
  
def get_fav():
    return("hello!")

@app.route("/newpost", methods=["GET", "POST"])
def write_new_post():
  print("On route newpost")
  if fk.request.method == "POST":
    title = fk.request.form["subject"]
    print("Newpost 1")
    text = fk.request.form["content"]
    print("Newpost 2")
  else:
    return fk.render_template("newpost.html")
  if (len(title) < 3 or len(text) < 10):
    print("Newpost 3")
    return fk.render_template("newpost.html", ph_subject=title, ph_content=text, ph_error="Your post title or post content are too short (minimum 3 characters for titles, minimum 10 characters for content).")
  else:
    conn = get_connection()
    print("Newpost 4")
    cur = conn.cursor()
    print("Newpost 5")
    # current_date = datetime.datetime.now()
    # current_date = current_date.\
    # replace(tzinfo=datetime.timezone.utc)
    # current_date = current_date.isoformat()
    # current_date = str(current_date)
    # current_date.replace("T", " ")
    # print(current_date)
    print("Newpost 7")
    cur.execute("INSERT INTO posts (create_date, subject, content) VALUES (?, ?, ?)", (fk.request.form["subject"], datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), fk.request.form["content"]))
    print("Post submitted into database!")
    conn.commit()
    return fk.render_template("posts.html", posts=get_posts())

#... ('/blog', m...,strict_slashes=False)
@app.route('/blog', methods=['GET'], strict_slashes=False)
def write_blog():
  print("On route blog")
  return fk.render_template("posts.html", posts=get_posts())

#... ('/', m...)
@app.route('/', methods=['GET'])
def root():
    print("On route root")
    method = fk.request.method
    with sqlite3.connect("blogbosts.db") as con:
        cursor = con.cursor()
        cursor.execute("CREATE TABLE IF NOT EXISTS posts (id INTEGER PRIMARY KEY, create_date TEXT, subject TEXT, content TEXT)")
        s = cursor.execute("SELECT * FROM posts ORDER BY create_date DESC").fetchall()
        print([x for x in s])
        print("Returning the write_post function...")
        return(write_posts(get_posts()))

@app.route('/post/post_id', methods=["GET", "POST"])
def permapost(post_id):
  return fk.render_template("post.html", post=get_post_by_id(post_id))

app.run(host='0.0.0.0', port=3000)