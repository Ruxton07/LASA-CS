import flask as fk
import logging
import sqlite3
import time
from datetime import datetime, timezone

app = fk.Flask(
    __name__,
    static_folder="static",
    template_folder="templates",
)
# connection=sqlite3.connect("AsciiArt.db")
# cursor=connection.cursor()
# s=cursor.execute("CREATE TABLE IF NOT EXISTS Art (id INTEGER PRIMARY KEY, title TEXT, art TEXT, creation TEXT)")
# insert_values = ("Test", "dlkfsdkl", str(datetime.now(timezone.utc)))
# s=cursor.execute("INSERT INTO Art (title, art, creation) VALUES (?, ?, ?)", insert_values)
# art=[x for x in s]
# print(art)

def render_ascii():
  with sqlite3.connect("AsciiArt.db") as con:
      cursor = con.cursor()
      s = cursor.execute("SELECT * FROM Art ORDER BY creation DESC").fetchall()
      print(s)
      return(fk.render_template(
          'home.html',
          error="",
          arts=s
      ))

@app.route('/', methods=["GET", "POST"])
def root():
  with sqlite3.connect("AsciiArt.db") as con:
    cursor = con.cursor()
    method = fk.request.method
    if method == "GET":
      logging.info("********** root GET **********")
      s=cursor.execute("CREATE TABLE IF NOT EXISTS Art (id INTEGER PRIMARY KEY, title TEXT, art TEXT, creation TEXT)")
      #d=[con.execute("SELECT * FROM Art ORDER BY creation DESC")]
      return render_ascii()
      
@app.route('/home', methods=['GET', 'POST'])
def submitted():
  with sqlite3.connect("AsciiArt.db") as con:
    cursor = con.cursor()
    logging.info("******TestForm " +  str(fk.request.method) + "******")
    title = fk.request.form["title"]
    logging.info("title=" + str(title) + " type=" + str(type(title)))
    art = fk.request.form["art"]
    logging.info("art=" + str(art) + " type=" + str(type(art)))
    creation = str(datetime.now(timezone.utc))
    logging.info("creation=" + str(creation) + " type=" + str(type(creation)))
    if title=="" or art=="":
      return fk.render_template("home.html", arts=[], error="Need both a title and some artwork!")
    else:
      if fk.request.method == "POST":
        insert_values = (title, art, creation)
        con.execute("INSERT INTO Art (title, art, creation) VALUES (?, ?, ?)", insert_values)
        return render_ascii()
      #d=[con.execute("SELECT * FROM Art ORDER BY creation DESC")]
      
      
  
app.run(host='0.0.0.0', port='3000')
