# Lab instructions on BLEND
import random
import logging
import flask as fk
import html
import re



def valid_user(user):
    try:
        ret = re.search("^[\w-]{3,20}$", user).group(0) == user
    except AttributeError:
        ret = False
    return ret


def valid_pass(password):
    try:
      ret = re.search("^.{3,20}$", password).group(0) == password
    except AttributeError:
      ret = False
    return ret


def valid_email(email):
    try:
      ret = re.search("^\w+@\w+\.\w+$", email).group(0) == email
    except AttributeError:
      ret = False
    return ret


# def write_form(user="", password="", vpassword="", email="", errorU="", errorP="", errorE=""):
#   return form % {"user": user, "password": password, "vpassword": vpassword, "email": email, "errorU": errorU, "errorP": errorP, "errorE": errorE}

app = fk.Flask(
    __name__,
    static_folder="stylesheets"
)

@app.route('/', methods=["GET", "POST"])
def root():
  return fk.render_template('home.html')

@app.route('/home', methods=['POST'])
def submitted():
  print("submitting")
  logging.info("******TestForm " +  str(fk.request.method) + "******")
  print("1")
  user = html.escape(fk.request.form["user"])
  print("2")
  logging.info("month=" + str(user) + " type=" + str(type(user)))
  password = html.escape(fk.request.form["password"])
  print("3")
  logging.info("day=" + str(password) + " type=" + str(type(password)))
  vpassword = html.escape(fk.request.form["vpassword"])
  print("4")
  logging.info("year=" + str(vpassword) + " type=" + str(type(vpassword)))
  email = html.escape(fk.request.form["email"])
  print("5")
  logging.info("email=" + str(email) + " type=" + str(type(email)))
  print(valid_user(user))
  print(valid_pass(password))
  print(password==vpassword)
  print(valid_email(email))
  print(email == "")
  if valid_user(user) and valid_pass(password) and password==vpassword and (valid_email(email) or email == ""):
    print("6")
    return fk.render_template("welcome.html", user=user, password=password, vpassword=vpassword, email=email)
  print("7")
  return fk.render_template("home.html", user=user, password=password, vpassword=vpassword, email=email, errorU=" That's not a valid username." if not valid_user(user) else "", errorP=" That's not a valid password." if not valid_pass(password) else (" Passwords do not match." if password!=vpassword else ""), errorE=" That's not a valid email." if not valid_email(email) and email!="" else "")

@app.route('/welcome', methods=["POST"])
def welcome():
    user = fk.request.form['user']
    logging.info("username=" + str(user) + " type=" + str(type(user)))
    return fk.render_template("home.html", username=user)

if __name__ == "__main__":
  app.run(host='0.0.0.0', port=5000)