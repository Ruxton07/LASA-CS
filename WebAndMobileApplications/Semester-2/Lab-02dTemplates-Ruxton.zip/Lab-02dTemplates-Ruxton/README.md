<center><b>Lab: 02d.Templates</b></center><br><br>

In this lab you will recreate the signup lab 'Lab: 02c.Signup' using templates.

You will provide three templates located in the '***>templates***' folder; base.html, home.html, and welcome.html.

