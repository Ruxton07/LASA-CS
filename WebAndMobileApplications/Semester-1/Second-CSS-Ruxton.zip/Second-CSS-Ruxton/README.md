Try to recreate the a web page like the following image (except for the green border)

 

.