Using the tags that control a list, recreate the web page in the image (except for the orange border).

 

.