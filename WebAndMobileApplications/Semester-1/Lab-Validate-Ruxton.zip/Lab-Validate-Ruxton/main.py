import flask as fl
import random
import logging
import html

logging.basicConfig(level=logging.DEBUG)

form = """What is your birthday?<br>
<form method="post" action="/submitted">
<label>Month</label><input type="text" name="month" value="%(month)s"><br>
<label>Day</label><input type="text" name="day" value="%(day)s"><br>
<label>Year</label><input type="text" name="year" value="%(year)s"><br>
<div style="color: red">%(error)s</div>
<input type="submit">
</form>
"""

app = fl.Flask(__name__)

def valid_day(d):
  return 0<d<32

def valid_month(m):
  months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
  for i in months:
    if m.startswith(i): return True
  return False

def valid_year(y):
  return y>1900 and y<2023

def valid_date(m, d, y):
  if d and y:
    d = int(d)
    y = int(y)
    vm = valid_month(m)
    vd = valid_day(d)
    vy = valid_year(y)
    print("-----")
    print(vm)
    print(vd)
    print(vy)
    print("-----")
    return vm and vd and vy
  return False

def write_form(month="", day="", year="", error=""):
  return form % {"month": month, "day": day, "year": year, "error": error}

@app.route("/")
def hello_world():
  return write_form()

@app.route("/formPage", methods=["GET"])
def form_handler():
  return(write_form("that is not correct"))
  

@app.route('/submitted', methods=['POST'])
def submitted():
  print("submitting")
  logging.info("******TestForm " +  str(fl.request.method) + "******")
  month = fl.request.form["month"]
  logging.info("month=" + str(month + " type=" + str(type(month))))
  day = fl.request.form["day"]
  logging.info("day=" + str(day + " type=" + str(type(day))))
  year = fl.request.form["year"]
  logging.info("year=" + str(year + " type=" + str(type(year))))
  if not valid_date(fl.request.form["month"], fl.request.form["day"], fl.request.form["year"]):
    print("bad data")
    return write_form(fl.request.form["month"], fl.request.form["day"], fl.request.form["year"], "Invalid date")
  else:
    print("redirecting to success")
    return (fl.redirect(fl.url_for("success_fn"), code=308))

@app.route("/success_fn", methods = ["POST"])
def success_fn():
  return "Success!"
if __name__ == "__main__":
  app.run(host='0.0.0.0', port=random.randint(2000, 9000))
