Start by putting the provided HTML in the body of the HTML document (index.html).

 

Then construct the CSS file (style.css) to achieve this result;

 

.