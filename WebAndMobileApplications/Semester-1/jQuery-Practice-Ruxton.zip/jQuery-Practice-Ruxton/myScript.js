$(document).ready(function() {
  
  $("#theRedButton").on("click", function() {
    $("h1").css("color", "red");
    $("h2").css("color", "red");
    $("h3").css("color", "red");
  })

  $("#theSpeakersButton").on("click", function() {
    $("#speakerHeading").fadeOut(1000);
  })
})
