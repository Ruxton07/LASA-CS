let currentColor = "black";

// builds grid of numRows x numCols <div> elements
var buildEtch = function(sz) {
  var container = $('.container');
  container.empty();
  console.log(container.firstChild);
  var boxSize = container.height() / sz;
  for (let i = 0; i < sz; i++) {
    var row = $('<div class ="row"></div>');
    for (let j = 0; j < sz; j++) {
      var cell = $('<div class ="cell"></div>');
      row.append(cell);
      cell.css("width", boxSize);
      cell.css("height", boxSize);
      cell.css("background-color", "white");
    }
    container.append(row);
    row.css("height", boxSize);
    row.css("width", container.height());
    row.css("display", "flex");
  }
  console.log("boxSize =", boxSize);
};

$(document).ready(function() {
  $('#resChange').click(function() {
    haveSize = false;
    while (haveSize === false) {
      oldSize = size;
      size = prompt("Please enter a grid size from 1-128");
      if (size > 0 && size <= 128) {
        haveSize = true;
      } else if (size === null) {
        size = oldSize;
        haveSize = true;
      } else {
        alert("The number you entered is outside the range!")
      };
    };
    buildEtch(size);
    $(".cell").on("mouseenter", function() {
      if (currentColor == "random")
        $(this).css("background-color", "rgb(" + Math.floor(Math.random() * 256) + "," + Math.floor(Math.random() * 256) + "," + Math.floor(Math.random() * 256) + ")");
      else
        $(this).css("background-color", currentColor);
    });

    $("#blackSelect").on("click", function() {
      currentColor = "black";
    });

    $("#redSelect").on("click", function() {
      currentColor = "red";
    });

    $("#blueSelect").on("click", function() {
      currentColor = "blue";
    });

    $("#yellowSelect").on("click", function() {
      currentColor = "yellow";
    });

    $("#randomSelect").on("click", function() {
      currentColor = "random";
    });
  });

  size = 50;
  buildEtch(size);

  $(".cell").on("mouseenter", function() {
    if (currentColor == "random")
      $(this).css("background-color", "rgb(" + Math.floor(Math.random() * 256) + "," + Math.floor(Math.random() * 256) + "," + Math.floor(Math.random() * 256) + ")");
    else
      $(this).css("background-color", currentColor);
  });

  $("#blackSelect").on("click", function() {
    currentColor = "black";
  });

  $("#redSelect").on("click", function() {
    currentColor = "red";
  });

  $("#blueSelect").on("click", function() {
    currentColor = "blue";
  });

  $("#yellowSelect").on("click", function() {
    currentColor = "yellow";
  });

  $("#randomSelect").on("click", function() {
    currentColor = "random";
  });
});