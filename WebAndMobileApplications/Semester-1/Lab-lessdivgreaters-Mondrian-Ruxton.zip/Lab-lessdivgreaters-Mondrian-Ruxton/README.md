 

# &lt;div&gt;s Mondrian 

Use HTML and CSS to create a web version of the Mondrian of the Mondrian shown below.

 

Detailed instructions: https://docs.google.com/document/d/1CjHuJ1g0uYHSVHsTlod0D5Tkcv4bpEfpkZwLOMxTI50/edit?usp=sharing

The Mondrian is constructed entirely of different size boxes, each of which is represented by a <div> element styled to the appropriate dimensions and color. 

# You **_cannot_** use 

- a **&lt;table&gt;** element 
- border, margin, or padding styling for your **&lt;div&gt;**s