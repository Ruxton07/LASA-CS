# See the finished product here: https://Cookies-2.alexyang4.repl.co
import flask as fk
import logging
import hashlib  #import the python hash function library


def write_site(message=""):
  return fk.render_template('main.html', message=message)


def hash_str(s):
  #return the hashdigest created byhashlib's md5 hash of str(s).encode("utf-8")
  return hashlib.md5(str(s).encode("utf-8")).hexdigest()


def make_secure_val(s):
  return s + '|' + hash_str(s)
  # return string that is a concatenation of s + '|' + hash_str(s))) - '+' symbols represent a concatenation operations.


# Take the string with  visits and the hash and return the confirmed results.
def check_secure_val(h):
  h_arr = h.split("|")
  print("h " + h)
  s = h_arr[0]
  hash = h_arr[1]
  # return s if the hash_str(s) equals hash, otherwise return None
  return s if hash_str(s) == hash else None


app = fk.Flask(__name__, static_folder="stylesheets")


def get_msg(visits):
  msg = "Visits: " + str(visits)
  if visits == 10000: msg = "Congrats! You are our 10,000th customer!"
  return msg


@app.route('/', methods=["GET"])
def root():
  method = fk.request.method
  if method == "GET":
    msg = ""
    # Get the number of visits from the request's cookie
    hash_visits = make_secure_val('visits')
    if hash_visits:
      # Get the confirmed number of visits in hash_visits by calling check_secure_val
      visits = fk.request.cookies.get(hash_visits)
      if visits:
        #update the visits count
        visits = int(visits)
        msg = get_msg(visits)
        print(visits)
        print("5")
        visits += 1
        
      else:
        # Warn the user "Don't mess with my cookie!"
        print("6")
        msg = "Don't mess with my cookie!"

    else:
      print("7")
      visits = 1
      msg = get_msg(visits)
    # Prepare the response object
    resp = fk.make_response(write_site(msg))
    # Set the response's cookie with 'visits', by making a _secure_val
    resp.set_cookie(make_secure_val("visits"), str(visits))
    return (resp)


app.run(host='0.0.0.0', port=3000)
