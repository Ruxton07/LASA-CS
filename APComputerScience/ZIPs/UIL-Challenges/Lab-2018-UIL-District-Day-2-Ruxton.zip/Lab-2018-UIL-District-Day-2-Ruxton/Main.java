import  java.io.*;

class Main {

  private static final String [] progs = {"Alice", "Bayani", "Candela", "Carla", "DryRun", "Diya", "Gleb", "Jeremy", "Kinga", "Layla", "Max", "Nandita", "Raymond"};
  public static void main(String[] args) throws IOException {
    Candela.main(args);
    Bayani.main(args);
    Gleb.main(args);
    //Timothy.main(args);
    
  }
}


