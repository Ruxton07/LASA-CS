import  java.io.*;

class Main {

  private static final String [] progs = {"Alice", "Bayani", "Candela", "Carla", "DryRun", "Diya", "Gleb", "Jeremy", "Kinga", "Layla", "Max", "Nandita", "Raymond"};
  public static void main(String[] args) throws IOException {
    Alice.main(args);
    Bayani.main(args);
  }
}


