class Bayani {
  public static void main(String[] args) {
System.out.println("    $ 6.99\n    $ 12.87\n    $ 5.44\n    $ 99.99\n    $ 115.87\nTotal = $ 241.16");
  }
}