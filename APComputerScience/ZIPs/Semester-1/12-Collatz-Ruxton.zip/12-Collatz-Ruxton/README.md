Lab: Collatz Instructions

https://docs.google.com/document/d/1TKC45I9ZGvg82XGRzkpnoEnlxtC9xXnPdiv9Qmajf9g/edit?usp=sharing

Sample Output

```
Starting Number 5
```

```
Starting Number 5 takes 6 steps
```

```
Number of steps 6
```

```
Maximum value 16
```

```
Minimum odd value 5
```

```
Odd values [5, 1]
```

```
Sum of all values 36
```

```
step 1 5
```

```
step 2 16
```

```
step 3 8
```

```
step 4 4
```

```
step 5 2
```

```
step 6 1
```

