Write a program that 

- asks **What is your name?** and then prints

`Hello name!`

- asks **How old are you?** and then prints

`Your age in months is ageInMonths.`

- asks **What is your favorite band?** and **What is your 2nd favorite band?** and then prints (NOTE: each band name could be more then one word - e.g. Pink Floyd).  

`I like band A and band B too!!!`




**A Run might look like ( <= denotes input):**

What is your name?                    <= 50 cent

Hello 50 cent!

How old are you?                      <= 12

Your age in months is 144.

What is your favorite band?           <= Beethoven

What is your 2nd favorite band?       <= Mozart

I like Beethoven and Mozart too!!!