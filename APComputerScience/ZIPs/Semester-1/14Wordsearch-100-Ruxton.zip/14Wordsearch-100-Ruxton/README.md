This code is for student who choose only to attempt the 100% goal.

Do not change Main.java.

All changes should be in WordSearch.java and WordSearchRunner.java

There are only two sets of test data; words1.txt and words2.txt

