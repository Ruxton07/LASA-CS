public class Main {
  public static void main(String[] args) {
    System.out.println("My name is Ryan Kellar.");
    System.out.println("I am a sophomore.");
    System.out.println("My favorite color is blue.");
  }
}