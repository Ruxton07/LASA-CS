 Start with the program on the left and add 3 print statements to

    - print My name is _`???`_.
    - print I am a _`freshman/sophomore/junior/senior`_.
    - print My favorite color is _`color`_.

NOTE don't forget the period at the end of each statement.

Intentionally make some errors to see how repl.it responds

- leave out the `;` at the end of one of your statements
- leave out the closing `)` in one of your statements
- misspell your name
- etc