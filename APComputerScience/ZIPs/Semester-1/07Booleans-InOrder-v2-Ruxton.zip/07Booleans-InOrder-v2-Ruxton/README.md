Lab: InOrder Instructions

https://docs.google.com/document/d/16mid7ZD82CE8FncSMgcuYh03Th_QaL1nG8yKt7AJqlk/edit?usp=sharing

Output should be in the following form:

 

**Enter x, y, and z: 5 7 6**

**5 <= 7 <= 6 is false**

**The original order is 5 7 6**

**The sorted order is 5 6 7**

**The middle number is 6**

