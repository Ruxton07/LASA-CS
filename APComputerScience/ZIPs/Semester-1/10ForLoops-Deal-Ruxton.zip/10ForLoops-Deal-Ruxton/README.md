Instructions at:

https://docs.google.com/document/d/1sVLufUxepHqn-LOxbNyygYfOUL54SvWlnDYHfGiCMIA/edit?usp=sharing