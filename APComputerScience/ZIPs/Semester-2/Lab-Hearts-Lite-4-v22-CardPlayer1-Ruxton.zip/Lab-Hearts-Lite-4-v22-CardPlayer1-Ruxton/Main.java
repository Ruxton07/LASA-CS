import java.util.*;    // required to use ArrayList

public class Main {
  public static void main(String[] args) {
    System.out.println("Hello world!");
    //CardPlayerLevel1 cp1 = new CardPlayerLevel1();
    TestCardPlayerLevel1();
  }

  // test the getValue() and compareCard() methods
  public static void TestCardPlayerLevel1() 
  {
    /*
    *
    *   Your Test for CardPlayerLevel.java
    *
    */
  }

}