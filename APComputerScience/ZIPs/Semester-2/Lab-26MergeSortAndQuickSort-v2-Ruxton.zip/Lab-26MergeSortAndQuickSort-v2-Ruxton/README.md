Lab: 26 Merge And Quick Sort Algorithms

You will complete the code in;

  1. MergeSort.java
  2. QuickSort.java

The main entry for both Classes is;

  public static String[] sort(String[] array)

The sort routine will be passed an array of differing sizes in ascending, descending, and random order.  You will sort the arrays into Lexicographically ascending order.

You may create any helper methods that you deem appropriate.

