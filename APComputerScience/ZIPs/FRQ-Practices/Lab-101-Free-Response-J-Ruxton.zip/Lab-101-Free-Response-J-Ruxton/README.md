Before you can test Problem 1a.

- in Crossword.java add return false to method **toBeLabeled**
- in LogMessage.java add return false to method **containsWord**
- in StringFormatter.java add return 0 to methods **totalLetters** & **basicGapWidth**
- in StringFormatter.java add return null to method **format**
- in SystemLog.java add return null to method **removeMessages**
- complete 1b. the RandomLetterChooser constructor.