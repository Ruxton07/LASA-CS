public interface MenuItem
{

	String getName();
	
	double getPrice();
}
